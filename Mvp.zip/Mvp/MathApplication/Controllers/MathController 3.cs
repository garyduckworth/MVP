﻿using System;
using System.Net.Http;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace MathApplication.Controllers
{
    /// <summary>
    /// Math controller
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class MathController : ControllerBase
    {
        // Variables
        private readonly ILogger<MathController> _logger;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Default constructor
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="configuration">Configuration</param>
        public MathController(ILogger<MathController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        /// <summary>
        /// Post math calculation
        /// </summary>
        /// <param name="expression">Expression</param>
        /// <param name="precision">Precision</param>
        /// <returns>Result</returns>
        [HttpGet]
        public string Get(string expression, string precision = "")
        {
            // Initialise
            string result;
            var mathExpression = HttpUtility.UrlEncode(expression);
            var primaryMathLink = _configuration.GetValue<string>("PrimaryMathLink");
            var secondaryMathLink = _configuration.GetValue<string>("SecondaryMathLink");
            mathExpression += (precision != "") ? "&precision=" + precision : "";

            // Run calculation
            var success = RunCalculation(primaryMathLink, mathExpression, out result);
            success = (success) ? true : RunCalculation(secondaryMathLink, mathExpression, out result);

            // Log error
            if (!success)
            {
                _logger.LogError(result);
            }

            // Return
            return result;
        }

        /// <summary>
        /// Post math calculation
        /// </summary>
        /// <param name="expression">Expression</param>
        /// <param name="precision">Precision</param>
        /// <returns>Result</returns>
        [HttpPost]
        public string Post(string expression, string precision = "")
        {
            // Initialise
            string result;
            var mathExpression = HttpUtility.UrlEncode(expression);
            var primaryMathLink = _configuration.GetValue<string>("PrimaryMathLink");
            var secondaryMathLink = _configuration.GetValue<string>("SecondaryMathLink");
            mathExpression += (precision != "") ? "&precision=" + precision : "";

            // Run calculation
            var success = RunCalculation(primaryMathLink, mathExpression, out result);
            success = (success) ? true : RunCalculation(secondaryMathLink, mathExpression, out result);

            // Log error
            if (!success)
            {
                _logger.LogError(result);
            }

            // Return
            return result;
        }

        /// <summary>
        /// Run math calculation
        /// </summary>
        /// <param name="mathLink">Math Link</param>
        /// <param name="expression">Expression</param>
        /// <param name="result">Result</param>
        /// <returns>Success</returns>
        private bool RunCalculation(string mathLink, string expression, out string result)
        {
            // Initialise
            var success = false;
            result = "";

            try
            {
                // Set client
                using (var client = new HttpClient())
                {
                    // Run calculation
                    var response = client.GetStringAsync(mathLink + expression);
                    response.Wait();

                    // Process result
                    if (response.IsCompletedSuccessfully)
                    {
                        result = response.Result;
                        success = true;
                    }
                }

            }

            // Catch exception
            catch (Exception e)
            {
                result = e.InnerException.Message;
            }

            // Return
            return success;
        }
    }
}
