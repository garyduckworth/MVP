﻿// APP
angular
    .module('app')
    .controller('controller', controller);

// CONTROLLER
function controller($scope, $compile) {

    // INITIALISE
    $scope.title = 'controller';
    $scope.expression = "1+1";
    $scope.precision = "";
    $scope.result = "2";

    // HEADERS
    var headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    };

    // INIT DATA
    $scope.initData = function () {
        $.get("/Home/Data", function (data) {
            $("#HomeData").html(data);
            $compile($("#HomeData"))($scope);
            $scope.$apply();
        });
    };

    // CALC DATA (GET)
    $scope.GetCalcData = function () {
        var expression = encodeURIComponent($scope.expression);
        var precision = ($scope.precision != "") ? "&precision=" + $scope.precision : "";
        $.get("api/math/?expression=" + expression + precision, function (data) {
            $scope.result = data;
            $scope.$apply();
        });
    };

    // CALC DATA (POST)
    $scope.PostCalcData = function () {
        var expression = encodeURIComponent($scope.expression);
        var precision = ($scope.precision != "") ? "&precision=" + $scope.precision : "";
        $.post("api/math/?expression=" + expression + precision, function (data) {
            $scope.result = data;
            $scope.$apply();
        });
    };
}
